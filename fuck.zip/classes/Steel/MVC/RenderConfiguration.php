<?php
namespace Steel\MVC;

class RenderConfiguration{
    public $disable_css_autoload = false;
    public $disable_js_autoload = false;
}