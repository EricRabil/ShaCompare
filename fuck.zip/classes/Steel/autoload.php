<?php

$dir = dirname(__FILE__);
require $dir . '/Settings.php';
require $dir . '/ArrayMethods.php';
require $dir . '/IApplication.php';
require $dir . '/MVC/MVCBundle.php';
require $dir . '/MVC/MVCIdentifier.php';
require $dir . '/MVC/IModel.php';
require $dir . '/MVC/IErrorModel.php';
require $dir . '/MVC/IController.php';
require $dir . '/MVC/IErrorController.php';
require $dir . '/MVC/IView.php';
require $dir . '/Database/IConnection.php';
require $dir . '/Database/Connection.php';
require $dir . '/MVC/RenderConfiguration.php';